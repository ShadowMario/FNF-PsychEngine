Achievements need json and a Lua or Haxe file with the same name.

To sort achievements, you can put numbers at the start of file names.
For example:

0_achievement.json
0_achievement.lua

1_achievement.json
1_achievement.lua